import caz from 'caz'

// 由于历史关系，很多第三方的 npm 包，当时都没有类型补充声明
import express from 'express'
import cors from 'cors'

caz('')

const app = express()
