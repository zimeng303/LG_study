declare module 'cors' {
  const fn: () => () => {}
  export default fn
}