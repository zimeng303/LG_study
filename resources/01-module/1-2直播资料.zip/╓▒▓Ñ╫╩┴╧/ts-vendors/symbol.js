// const key = Symbol('xxx_key')

// export default {
//   [key]: 'hello',
//   foo () {
//     this[key]
//   }
// }

console.log(this === module.exports)