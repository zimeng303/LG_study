function fn (a, b, c) {
  console.log(this)
  return a + b + c
}
const obj = {
  name: 'xxx'
}
// fn.call(obj, 1,2,3)

Function.prototype.mycall = function (context, ...args) {
  context = context || window
  // obj.fn()
  // context.fn = this

  Object.defineProperty(context, 'fn', {
    value: this,
    enumerable: false,
    configurable: true
  })

  // console.log(Object.getOwnPropertyDescriptor(context, 'fn'))
  const result = context.fn(...args)
  delete context.fn
  return result
}

fn.mycall(obj, 1, 2, 3)

console.log(obj)

