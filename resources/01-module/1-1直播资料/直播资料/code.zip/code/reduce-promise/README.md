## reduce 和 Promise

https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Array/Reduce#%E6%8C%89%E9%A1%BA%E5%BA%8F%E8%BF%90%E8%A1%8CPromise