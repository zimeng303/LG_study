export default (props) => <h1>{props.name}</h1>;
