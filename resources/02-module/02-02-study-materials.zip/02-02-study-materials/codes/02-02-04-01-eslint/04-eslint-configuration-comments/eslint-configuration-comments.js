const str1 = "${name} is a coder" // eslint-disable-line no-template-curly-in-string 

console.log(str1)

