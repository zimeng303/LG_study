const a = 1

console.log("中文");

