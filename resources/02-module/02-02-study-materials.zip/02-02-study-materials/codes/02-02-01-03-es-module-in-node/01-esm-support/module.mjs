export const foo = 'hello'

export const bar = 'world'
