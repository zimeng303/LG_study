export default {
  hi: 'Hey Guys, I am zce~'
}
