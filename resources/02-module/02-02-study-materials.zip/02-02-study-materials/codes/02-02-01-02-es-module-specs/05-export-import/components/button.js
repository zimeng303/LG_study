var Button = 'Button Component'

export default Button
