export function lowercase (input) {
  return input.toLowerCase()
}
