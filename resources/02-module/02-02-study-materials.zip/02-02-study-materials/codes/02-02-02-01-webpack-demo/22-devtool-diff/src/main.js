import createHeading from './heading.js'

const heading = createHeading()

document.body.append(heading)

console.log('main.js running')

console.log111('main.js running')
