export default () => {
  return document.createElement('button')

  console.log('dead-code')
}
