import about from './about.md'

console.log(about)
