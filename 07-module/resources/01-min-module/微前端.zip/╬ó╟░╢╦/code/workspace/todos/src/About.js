import React from "react"

const About = () => {
  return <div>About works</div>
}

export default About
