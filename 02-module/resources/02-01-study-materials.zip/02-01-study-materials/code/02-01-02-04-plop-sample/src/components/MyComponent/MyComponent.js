import React from 'react';

export default () => (
  <div className="MyComponent">
    <h1>MyComponent Component</h1>
  </div>
)