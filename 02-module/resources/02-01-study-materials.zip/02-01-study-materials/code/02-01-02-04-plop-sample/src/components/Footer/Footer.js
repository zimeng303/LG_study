import React from 'react';

export default () => (
  <div className="Footer">
    <h1>Footer Component</h1>
  </div>
)