;((window, document) => {
  document.querySelector('#btn').addEventListener('click', () => {
    alert(Date.now())
  })
})(window, document)
