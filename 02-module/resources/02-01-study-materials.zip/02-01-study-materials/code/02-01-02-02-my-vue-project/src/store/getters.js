export default {
  count: state => state.count
}
