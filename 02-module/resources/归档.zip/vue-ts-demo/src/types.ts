export type Foo = {
  name: string
}