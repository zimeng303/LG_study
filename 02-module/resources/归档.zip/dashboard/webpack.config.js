
/** @type {import('webpack').Configuration} */
// module.exports = {
//   entry: './src/index.js',
//   module: {
//     rules: [
//       {
//         test
//       }
//     ]
//   }
// }
