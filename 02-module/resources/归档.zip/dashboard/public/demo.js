// const app = document.getElementById('app')

// /**
//  * @param {HTMLElement} el
//  */
// function appendTable (el) {
//   el.appendChild
// }

// // @ts-check

// /** @type {number | string} */
// let foo

// foo = 123

// foo = '1231'

//

// /** @typedef {'open' | 'close'} Status */


// /** @type {Status} */
// let bar = 'close'
