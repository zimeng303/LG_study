/**
 * Wrapper NProgress with style
 */

import 'nprogress/nprogress.css'
import nprogress from 'nprogress'

// config
nprogress.configure({
  // parent: '#content',
  // minimum: 0.1,
  // easing: 'ease',
  // speed: 50,
  // trickle: false,
  // trickleRate: 0.02,
  // trickleSpeed: 800,
  showSpinner: false
})

export default nprogress
