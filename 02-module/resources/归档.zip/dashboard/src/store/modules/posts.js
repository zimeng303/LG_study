/**
 * Initial state
 */
const state = {

}

/**
 * Getters
 */
const getters = {

}

/**
 * Mutations
 */
const mutations = {

}

/**
 * Actions
 */
const actions = {

}

// Export module
export default { state, getters, mutations, actions }
