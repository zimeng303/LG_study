import options from './options'
import users from './users'
import terms from './terms'
import posts from './posts'
import comments from './comments'

export default { options, users, terms, posts, comments }
