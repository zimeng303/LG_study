<template>
  <div>
    <div class="heading">
      <h1 class="title">Import</h1>
    </div>
    <p>Not yet!</p>
  </div>
</template>

<script>
export default {
  name: 'import'
}
</script>
