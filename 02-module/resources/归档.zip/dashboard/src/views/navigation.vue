<template>
  <div>
    <div class="heading">
      <h1 class="title">Navigation</h1>
    </div>
    <p>Not yet!</p>
  </div>
</template>

<script>
export default {
  name: 'navigation'
}
</script>
