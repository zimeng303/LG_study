<template>
  <div>
    <div class="heading">
      <h1 class="title">Permissions</h1>
    </div>
    <p>Not yet!</p>
  </div>
</template>

<script>
export default {
  name: 'permissions'
}
</script>
