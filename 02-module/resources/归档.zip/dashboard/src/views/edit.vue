<template>
  <div>
    <div class="heading">
      <h1 class="title">Edit {{ $route.params.type }}</h1>
    </div>
    <p>Not yet!</p>
  </div>
</template>

<script>
export default {
  name: 'edit'
}
</script>
