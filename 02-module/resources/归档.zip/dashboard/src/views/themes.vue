<template>
  <div>
    <div class="heading">
      <h1 class="title">Themes</h1>
    </div>
    <p>Not yet!</p>
  </div>
</template>

<script>
export default {
  name: 'themes'
}
</script>
