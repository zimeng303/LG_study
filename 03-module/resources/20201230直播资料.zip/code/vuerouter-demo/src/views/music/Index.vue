<template>
  <div>
    <div id="nav">
      <router-link to="/music/pop">Pop</router-link> |
      <router-link to="/music/rock">Rock</router-link>
    </div>
    <router-view/>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
