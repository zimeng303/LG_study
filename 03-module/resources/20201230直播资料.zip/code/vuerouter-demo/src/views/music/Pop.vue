<template>
  <div>
    Pop Music
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
