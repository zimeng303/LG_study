import History from './base'

export default class HTML5History extends History {

}
