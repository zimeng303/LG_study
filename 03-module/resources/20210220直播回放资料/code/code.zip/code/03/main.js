var User = {
  count: 1,
  action: {
    // action 没有 count
    // getCount: function () {
    //   return this.count
    // }

    // 绑定外部 this
    // getCount: () => {
    //   return this.count
    // }

    // 它是 this 是什么，就是函数简写，没有任何特性
    // getCount () {} 等价于 getCount: function () {}，就是简写而已
    getCount () {
      return this.count
    }
  }
}

var getCount = User.action.getCount

User.getCount = User.action.getCount

console.log(User.getCount())

setTimeout(() => {
  // result 1 undefined
  console.log('result 1', User.action.getCount())
})

// 1. result 2 undefined
console.log('result 2', getCount())
