const { test, expect } = require('@jest/globals')
const { observe } = require('./main.js')

test('observe', () => {
  const man = {
    name: 'jscoder',
    age: 22,
    // man.obj = proxy(obj)
    obj: {
      a: 1
    }
  }
  const proxy = observe(man)
  expect(proxy.name).toBe('jscoder')
  expect(proxy.age).toBe(22)
  expect(() => proxy.location).toThrow()
  expect(proxy.obj.a).toBe(1)
  expect(() => proxy.obj.b).toThrow('does not exist')
})
