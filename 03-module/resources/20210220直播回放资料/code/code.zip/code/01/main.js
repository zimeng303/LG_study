// 80
function observe(data) {
  if (typeof data === 'object') {
    for (let key in data) {
      if (typeof data[key] === 'object') {
        data[key] = observe(data[key])
      }
    }
  }

  return new Proxy(data, {
    get(target, property) {
      // console.log('proxy get')
      if (property in target) {
        return target[property]
      }
      throw new Error(`Property “${property}” does not exist`)
    }
  })
}

// 导出
exports.observe = observe

// const proxy = observe(man)

// 最简单的实现：50
// const proxy = new Proxy(man, {
//   // 任何属性的访问都会调用 get 访问器函数
//   get(target, property) {
//     console.log('proxy get')
//     if (property in target) {
//       return target[property]
//     }
//     throw new Error(`Property “${property}” does not exist`)
//   }
// })

// console.log(proxy.name) // "jscoder"
// console.log(proxy.age) // 22
// // console.log(proxy.location) // Property "$(property)" does not exist
// console.log(proxy.obj.a)
// console.log(proxy.obj.b)

// proxy.name = 'jack'
// console.log(proxy.name)
// console.log(man.name)
