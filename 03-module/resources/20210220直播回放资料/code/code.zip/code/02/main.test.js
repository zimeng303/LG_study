const { test } = require('@jest/globals')
const { main } = require('./main')

// 使用模拟定时器
jest.useFakeTimers()

test('red-green-yellow', async () => {
  // 调用带有定时器的函数
  main()

  for (let i = 1; i <= 9; i++) {
    expect(setTimeout).toHaveBeenCalledTimes(i)
    await Promise.resolve().then(() => jest.runOnlyPendingTimers())
  }

  // 验证定时器被调用了1次
  // expect(setTimeout).toHaveBeenCalledTimes(1)

  // 让当前定时器时间快进结束
  // jest.runAllTimers()

  // 让正在运行的定时器快进结束
  // 如果你需要循环调用定时器，务必使用 runOnlyPendingTimers
  // jest.runOnlyPendingTimers()
  // 注意：它只针对函数中直接写 setTimeout 有效
  // 如果是异步 async/await 需要放到 Promise 中才能生效
  // await Promise.resolve().then(() => jest.runOnlyPendingTimers())

  // expect(setTimeout).toHaveBeenCalledTimes(2)

  // await Promise.resolve().then(() => jest.runOnlyPendingTimers())

  // expect(setTimeout).toHaveBeenCalledTimes(3)

  // await Promise.resolve().then(() => jest.runOnlyPendingTimers())

  // expect(setTimeout).toHaveBeenCalledTimes(4)
})
