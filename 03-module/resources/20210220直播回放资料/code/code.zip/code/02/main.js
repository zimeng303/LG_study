function red () {
	console.log('red')
}
function green () {
	console.log('green')
}
function yellow () {
	console.log('yellow')
}

function wait (time, callback) {
  return new Promise((resolve) => {
    setTimeout(() => {
      callback && callback()

      // 将状态变为成功
      resolve()
    }, time)
  })
}

async function main () {
  await wait(3000, red)
  await wait(2000, yellow)
  await wait(1000, green)
  main()
}

exports.main = main

// function main () {
//   wait(3000, red).then(() => {
//     return wait(2000, yellow)
//   }).then(() => {
//     return wait(1000, green)
//   }).then(() => {
//     main() // 开始新的一轮
//   })
// }

// 交替执行 red、greed、yellow
// main()

// wait(1000, red).then(() => {
//   console.log('OK')
// })

// await wait(1000, red)
