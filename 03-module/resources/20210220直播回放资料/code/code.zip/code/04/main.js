// 你觉得typescript和javascript有什么区别
// typescript你都用过哪些类型
// typescript中type和interface的区别
