<template>
  <div class="resource">资源管理</div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'ResourceIndex'
})
</script>

<style lang="scss" scoped></style>
