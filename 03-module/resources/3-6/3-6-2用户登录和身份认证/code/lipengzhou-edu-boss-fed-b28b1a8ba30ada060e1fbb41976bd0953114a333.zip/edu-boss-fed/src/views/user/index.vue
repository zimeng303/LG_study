<template>
  <div class="user">用户管理</div>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'UserIndex'
})
</script>

<style lang="scss" scoped></style>
