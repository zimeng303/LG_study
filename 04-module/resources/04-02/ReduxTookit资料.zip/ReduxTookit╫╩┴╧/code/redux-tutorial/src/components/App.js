import TodoContainer from "./Todos/Container"

function App() {
  return <TodoContainer />
}

export default App
